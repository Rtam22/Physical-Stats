export function roundToHalf(num: number): number {
  return Math.round(num * 2) / 2;
}

import "./App.css";
import MainPage from "./pages/mainPage";

function App() {
  return (
    <div>
      <MainPage />
    </div>
  );
}

export default App;
